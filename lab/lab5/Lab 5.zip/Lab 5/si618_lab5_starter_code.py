'''
created by hkarthik.
'''

class UpvotesAverageCalculator(MRJob):
    OUTPUT_PROTOCOL = mrjob.protocol.TextProtocol

    def mapper(self, _, line):
        try:
            # # +++your code here+++
            date = # date
            description = # string containing all category tags
            upvotes = # upvotes
            if description is not None:
                # # +++your code here+++
                tags = # get a list of all the tags from the description

                # hint: the mapper maps each category under a date with the upvotes and the product count
        except:
            pass
       
    def combiner(self, key, values):
        # # +++your code here+++

        # hint: the combiner combines to get the total upvotes and the total product counts

    def reducer(self, key, values):
        # # +++your code here+++

        # the reducer combines and reduces the total upvotes and total product counts to the average number of upvotes per product


if __name__ == '__main__':
    UpvotesAverageCalculator.run()
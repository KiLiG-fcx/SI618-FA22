File names take the following form

region_gamemode.csv.bz2

With
region = 
	na for North American server
	euw for Europe West
gamemode =
	ai = Artificial intelligence (i.e., vs the computer)
	normal_blind = Normal Blind (PvP)
	normal_draft = Normal Draft (PvP)
	ranked_solo = Ranked Solo Queue (PvP)
	ranked_team = Ranked Team Queue (PvP)
	group_finder = Group Finder mode (PvP)
	
Rows in each file consist of one summoner's information.	
	
Each file contains the following variable (columns)
	summonerId: Summoner Identification number
	matchId: Match ID number
	winner: 1 = won match, 0 lost
	kill: number of kills
	death: number of deaths
	assist: number of assists
	timeCreated: time stamp of match
	duration: duration of match (seconds)
	matchType: match type
	spell0: summoner spell ID in slot (0,1)
	spell1
	championId: champion ID
	championName: Champion's name
	item0: item ID in slot (0 - 6)
	item1
	item2
	item3
	item4
	item5
	item6
	goldEarned: gold earned during match
	goldSpent: gold psent during match
	inhibitorKills: number of inhibitor kills
	towerKills: number of tower kills
	sightWardsBought: sight wards purchased
	visionWardsBought: vision wards purchased
	wardsKilled: number of wards killed
	wardsPlaced: number of wards placed
	minionsKilled: total minons kills
	neutralMinionsKilled: number of neutral minions kills
	neutralMinionsKilledEnemyJungle: neutral minions killed in enemy team's jungle
	neutralMinionsKilledTeamJungle: neutral minions killed in own team's jungle
	totalDamageDealt: total damage dealt
	totalDamageDealtToChampions: total damage dealt to enemy champions
	totalDamageTaken: total damage taken
	trueDamageDealt: true damage dealt
	trueDamageDealtToChampions: true damage dealt to champions
	trueDamageTaken: true damage taken
	physicalDamageDealt: physical damage dealt
	physicalDamageDealtToChampions: physical damage dealt to enemy champions
	physicalDamageTaken: physical damage taken
	magicDamageDealt: magic damage dealt
	magicDamageDealtToChampions: magic damage dealt to enemy champions
	magicDamageTaken: magic damage taken
	totalHeal: total heal amount
	totalUnitsHealed: total number of units healed
	totalTimeCrowdControlDealt: total dealth crowd control time
	predictedRole: predicted role according to SVM model (0 = T, 1 = J, 2 = M, 3 = A, 4 = S)
	potentialRoles: 5 digit value with potential roles according to ChampionGG, following TJMAS order with 1 = primary, 2 = secondary, 0 = not listed as a role by ChampionGG
	Ability.Power: Number of items with <Variable name> bonus (0 - 6)
	Armor
	Armor.Penetration
	Attack.Damage
	Attack.Speed
	Bonus.Gold.per.Large.Monster.Kill
	Cooldown.Reduction
	Critical.Strike
	Damage.taken.from.Critical.Strikes
	Gold.per.10.seconds
	Health
	Health.Regen
	Life.Steal
	Magic.Damage.on.Hit
	Magic.Penetration
	Magic.Resistance
	Mana
	Mana.Regen
	Movement.Speed
	JungleItem: Number of items designated as a jungle item
	Cleanse: 1 = <Spell> selected, 0 not selected
	Teleport
	Ignite
	Ghost
	Heal
	Smite
	Exhaust
	Clarity
	Clairvoyance
	Barrier
	Flash
